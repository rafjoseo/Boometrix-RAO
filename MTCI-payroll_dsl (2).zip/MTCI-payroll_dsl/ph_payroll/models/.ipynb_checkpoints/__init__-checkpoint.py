# -*- coding: utf-8 -*-

from . import browsable_object
from . import hr_employee
from . import hr_salary_rule
from . import hr_payslip
from . import hr_payslip_line
from . import payslip_line_report
from . import hr_tax_table